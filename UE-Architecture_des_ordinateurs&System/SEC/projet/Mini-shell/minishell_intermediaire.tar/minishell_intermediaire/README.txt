# Nom de projet: minishell
# @Author: Guohao DAI
# Groupe E, 1A, SN, ENSEEIHT  
———————————————————————————————————————————————————————————
 Q1*, Q2, Q3, Q5: the loop is in "parse.c";
 Q4 : The commands "cd" and "exit" are in "builtin.c"
 Q6 : The commands "-jods", "-bg" and "-fg" are in "jobs.c"
 Q7, Q8, Q9, Q10 : "execute.c"

* I wrote another file named "parse.c".It likes "readcmd.c" which is given to me.

# Nom de projet: minishell
# @Author: Guohao DAI
# Groupe E, 1A, SN, ENSEEIHT  
—————————————————————————————————————————————————————
 Q1*, Q2, Q3 and Q5: the loop is in "parse.c";
 Q4 : The commands "cd" and "exit" are in "builtin.c"
 Q7, Q8, Q9 and Q10 : "execute.c"
 * I wrote another file named "parse.c".It likes "readcmd.c" which is given to me.
—————————————————————————————————————————————————————
 Q6 and Q7 are not implemented by code.
 For Q2.pdf, I have written my answer of question 2 in "Rapport_Intermédiaire_de_Minishell.pdf"
#ifndef _EXECUTE_H_
#define _EXECUTE_H_

int execute_disk_command(void);	//execute

#endif   //_EXECUTE_H_

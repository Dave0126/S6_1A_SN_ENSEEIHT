Bonjour Monsieur,

C'est Guohao. J'ai pratiquement terminé tous les TP. Le dernier exercice de TP3&4 est vide, car je ne sais vraiment pas comment le faire. 
Je vous remercie encore de m'avoir donné l'opportunité de soumettre un TP.

Cordialement,
Guohao.
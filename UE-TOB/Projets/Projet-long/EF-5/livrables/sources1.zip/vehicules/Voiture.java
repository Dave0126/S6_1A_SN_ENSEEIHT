package vehicules;


public class Voiture extends Vehicule {

    public Voiture() {
        super(0,4,0);
    }
}

package reseau;

/**
 * Liste les différents type de Noeuds instanciables.
 * @version 0.1
 * @author Adrien, Clément, Pierre-Louis
 */
public enum TypeNoeud {

	ENTREE_SORTIE,
	DEFAULT;
	
}

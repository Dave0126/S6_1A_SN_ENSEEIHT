- cluster_sans_masque.m : Affichage sous la forme d'un nuage de n points de R2 les deux premières composantes principales des visages sans masques de la base d'apprentissage.

- kppv.m : algorithme des k plus proches voisins

- subspace_iter_v3.m : Algorithme codé dans la partie 2

- expo_rapide.m : Calcul de la puissance d'une matrice pour la fonction précédente.

- eigenfaces_part3.m : calcule les eigenfaces pour les fonctions de reconnaissance. A LANCER AVANT LES FONCTIONS DE RECONNAISSANCE.

- reconnaissance_avec_masque.m : tire aléatoirement un individu avec masque et trouve la personne la plus proche de la base d'apprentissage à l'aide de kppv.

- reconnsaissance_sans_masque.m : tire aléatoirement un individu sans masque et trouve la personne la plus proche de la base d'apprentissage à l'aide de kppv.

- reconnaissance_reconstruction.m : tire aléatoirement un individu avec masque et trouve la personne la plus proche de la base d'apprentissage à l'aide de kppv. Reconstruit ensuite la visage de la personne tirée aléatoirement.

- test_reconnaissance.m : teste les performances du classificateur dans la reconnaissance des postures en créant une matrice de confusion.
